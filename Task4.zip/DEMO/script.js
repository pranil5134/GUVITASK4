//1.create a request variable
var request=new XMLHttpRequest();
//2.create a connection
request.open('GET','https://restcountries.eu/rest/v2/all',true);
//3.send the connection
request.send();
//4.register a event listner.once data is ready load the data
request.onload=function(){

    var countrydata=JSON.parse(this.response);
    /*for(let i in countrydata)
    {
     //console.log(countrydata[i].currencies[0].code);
    }*/
    
    
    console.log("1.Get all the countries from Asia continent / “region” using Filter function.")
    
    let filterdata=countrydata.filter((x)=>x.region=="Asia")
    let finaloutput=filterdata.map((x)=>x.name)

    console.log(finaloutput)


    console.log("2.Get all the countries with population of less than 2 lacs using Filter function.")
    let filter_pouplation=countrydata.filter((x)=>x.population<200000)
    let finalpopulation=filter_pouplation.map((x)=>x.name)

    console.log(filter_pouplation)

    console.log("3.Print the following details name, capital, flag using forEach function.")
    countrydata.forEach((x)=>console.log("{"+x.name,x.capital,x.flag+"}"))

    

    console.log("4.Print the total population of countries using reduce function.")
    let reduce_function=countrydata.reduce((acc,element)=>acc+element.population,0)
    console.log(reduce_function)

    console.log("5.Print the country which uses US Dollars as currency.")

    //let currency_filter=countrydata.filter((x)=>x.currencies.includes("USD"))
    countrydata.forEach((x)=>{
                for(let curr in x.currencies)
                {
                if(x.currencies[curr].code=="USD")
                {
                    console.log(x.name)
                
                }
            
            }}
            )
    
}